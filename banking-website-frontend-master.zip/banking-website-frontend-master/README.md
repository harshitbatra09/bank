# Front end design for Bank 

## used languges:
* HTML
* CSS
* bootstrap "framework"


## images:
![home preview](https://github.com/Abuelseaoud/Front-end-bank/blob/master/bank%20home.png)

![register preview](https://github.com/Abuelseaoud/Front-end-bank/blob/master/bank%20register.png)

